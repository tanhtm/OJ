if (self.CavalryLogger) { CavalryLogger.start_js(["CGS7z"]); }

__d("XUFIAuthorPinnedCommentController",["XController"],(function(a,b,c,d,e,f){e.exports=b("XController").create("/ufi/comment/author_pin/",{})}),null);